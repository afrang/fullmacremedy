<?php

namespace App\Model\Address;

use Illuminate\Database\Eloquent\Model;

class invoice_post_price extends Model
{
    //
}
