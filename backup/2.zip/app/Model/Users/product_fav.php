<?php

namespace App\Model\Users;

use Illuminate\Database\Eloquent\Model;

class product_fav extends Model
{
    //
}
