<?php

namespace App\Model\Medical;

use Illuminate\Database\Eloquent\Model;

class m_medicine extends Model
{
    //
}
