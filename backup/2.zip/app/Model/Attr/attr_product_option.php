<?php

namespace App\Model\Attr;

use Illuminate\Database\Eloquent\Model;

class attr_product_option extends Model
{

}
