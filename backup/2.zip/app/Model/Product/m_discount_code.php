<?php

namespace App\Model\Product;

use Illuminate\Database\Eloquent\Model;

class m_discount_code extends Model
{
    //
}
