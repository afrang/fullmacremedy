<?php

namespace App\Model\Product;

use Illuminate\Database\Eloquent\Model;

class p_special_products extends Model
{
    protected  $fillable=['category','label','image','location','idproduct'];
    function toProduct(){
        return $this->hasOne(p_prodcut::class,'id','idproduct');
    }

}
