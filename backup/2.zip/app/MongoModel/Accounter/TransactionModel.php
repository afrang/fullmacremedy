<?php

namespace App\MongoModel\Accounter;
use Jenssegers\Mongodb\Eloquent\Model;

class TransactionModel extends Model
{
    protected $collection = 'Transaction';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'parent',
        'log',
        'mode',
        'idmode',
        'payment',
        'recived',
        'bankname',
        'modelrecived',
        'inputer',
        'bankename',
        'datepayment',
        'peygiri',
    ];
}
