<?php

namespace App\MongoModel;

use App\User;
use Jenssegers\Mongodb\Eloquent\Model;

class dmrModel extends Model
{
    protected $collection = 'dmr';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'mobile',
        'phone',
        'fathername',
        'nationlcode',
        'birthday',
        'birthdayplace',
        'gender',
        'gender',
        'hname',
        'hphone',
        'triage',
        'hmobile',
        'city',
        'state',
        'address',
        'password',
        'mobile',
        'masterins',
        'Insurance',
        'bloodpressure',
        'diabet',
        'addiction',
        'heartdisease',
        'heartdiseasecomment',
        'heartdiseasef',
        'Kidney',
        'Kidneycomment',
        'Lung',
        'Lungcomment',
        'Internalglands',
        'surgery',
        'surgerycount',
        'surgerylast',
        'surgerydate',
        'Brainnerve',
        'Brainnervecomment',
        'Depression',
        'Suicide',
        'Hospitalization',
        'Hospitalizationlast',
        'Hospitalizationdate',
        'Hereditary',
        'Hearing',
        'Hearingright',
        'Vision',
        'Visionright',
        'Visiongleft',
        'Visiongcover',
        'medicalallergy',
        'Foodallergies',
        'Foodallergiescomment',
        'Bedsore',
        'Externaldevice',
        'Prosthesisplace',
        'Stent',
        'Stentcount',
        'pacemaker',
        'Nutrition',
        'lostweight',
        'Height',
        'weight',
        'dosepain',
        'mri',
        'sono',
        'radiology',
        'scan',
        'Medicineprescription',
        'other',
    ];


}
