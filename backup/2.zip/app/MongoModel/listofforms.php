<?php

namespace App\MongoModel;

use Jenssegers\Mongodb\Eloquent\Model;

class listofforms extends Model
{
    protected $collection = 'listofforms';
    protected $connection ='mongodb';
    protected $primary = 'id';

}
