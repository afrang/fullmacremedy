<?php

namespace App\MongoModel;

use App\MongoModel\Accounter\TransactionModel;
use App\User;
use Jenssegers\Mongodb\Eloquent\Model;

class TriageModel extends Model
{
    protected $collection = 'triage';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'GCS',
        'blood',
        'breath',
        'comment',
        'doctor',
        'hearth',
        'level',
        'modelservice',
        'oxygen',
        'price',
        'temp',
        'trapist',
        'user',
        'voice',
        'status',

    ];
    function toTransationRecived(){
        return $this->hasMany(TransactionModel::class,'parent','user')->where('recived','!=',null);
    }
    function toTransationPayment(){
        return $this->hasMany(TransactionModel::class,'parent','user')->where('payment','!=',null);
    }
}
