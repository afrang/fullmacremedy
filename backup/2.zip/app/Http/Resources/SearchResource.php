<?php

namespace App\Http\Resources;

use App\Http\Resources\Blog\BlogArticlethumpresource;
use App\Model\Blog\b_article;
use App\Model\Product\p_prodcut;
use Illuminate\Http\Resources\Json\JsonResource;

class SearchResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    private $product;
    private $article;
    public function  __construct($id,$page)
    {

        $product=p_prodcut::where('name','LIKE','%'.$id.'%')->paginate(15);

        $this->product['data']=ProdcutThumpnailResource::collection($product);
        $this->product['info']=$product;

        $article=b_article::where('name','LIKE','%'.$id.'%')->where('group','!=',1)->paginate(3);

        $this->article['data']=BlogArticlethumpresource::collection($article);
        $this->article['info']=$article;
    }

    public function toArray($request)
    {
       // return  $this->product;
        return[
            'productlist'=>$this->product,
            'articlelist' => $this->article,
        ];

    }
}
