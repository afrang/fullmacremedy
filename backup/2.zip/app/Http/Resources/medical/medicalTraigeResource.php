<?php

namespace App\Http\Resources\medical;

use App\MongoModel\dmrModel;
use App\User;
use Illuminate\Http\Resources\Json\JsonResource;

class medicalTraigeResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $user=User::where('id',$this->toTraige->user)->first();
        return[
            'traige'=>parent::toArray($request),
            'user'=>@$user,
            'dmr'=>@dmrModel::where('phone',$user->phone)->first()
            ];

    }
}
