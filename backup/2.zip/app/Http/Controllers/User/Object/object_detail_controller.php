<?php

namespace App\Http\Controllers\User\Object;

use App\Http\Controllers\Controller;
use App\Object\object_detail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class object_detail_controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(object_detail $detail)
    {
       return  $detail->with('topos')->get();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,object_detail $detail)
    {
        $save           =   new $detail;
        $save->pos      =        $request->pos;
        $save->name     =        $request->name;
        $save->save();
        return  $save;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id,object_detail $detail)
    {
        $save           =$detail->where('id',$id)->first();
        $save->file      =        $request->file;
        $save->name     =        $request->name;
        $save->pos     =        $request->pos;
        $save->height     =        $request->height;
        $save->width     =        $request->width;
        $save->save();
        return  $save;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id,object_detail $detail)
    {
       $del     =$detail->where('id',$id)->first();
       if($del->file!=null){
           Storage::disk('media')->deleteDirectory('object/'+$id);
       }
       $del->delete();
    }
}
