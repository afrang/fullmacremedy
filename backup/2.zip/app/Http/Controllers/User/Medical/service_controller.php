<?php

namespace App\Http\Controllers\User\Medical;

use App\Http\Controllers\Controller;
use App\Model\Medical\m_service;
use Illuminate\Http\Request;

class service_controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       return  m_service::where('sub',0)->with('toSub')->orderBy('ordered')->paginate(25);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request  $request,m_service  $m_service)
    {
       // return $request->sub;
            return $m_service->where('sub',$request->sub)->paginate(25);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,m_service  $m_service)
    {
        $request->validate([
            'name'=>[
                'required',
            ],
            'en'=>[
                'required',
            ],
        ]);
        $save =new  $m_service;
        $save->en = $request->en;
        $save->name = $request->name;
        $save->save();
        return  $save;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id,m_service  $m_service)
    {
        return  $m_service->find($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id,Request  $request)
    {
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id,m_service  $m_service)
    {

        $request->validate([
            'name'=>[
                'required',
            ],
            'en'=>[
                'required',
            ],
        ]);
        $save = $m_service->find($id);
        $save->description= $request->description;
        $save->en = $request->en;
        $save->name = $request->name;
        $save->color = $request->color;
        $save->icon = $request->icon;
        $save->image = $request->image;
        $save->sub = $request->sub;

        $save->save();
        return $save;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
