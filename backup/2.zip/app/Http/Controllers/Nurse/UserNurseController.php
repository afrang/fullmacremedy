<?php

namespace App\Http\Controllers\Nurse;

use App\Http\Controllers\Controller;
use App\Http\Controllers\Tools\SendSmsController;
use App\MongoModel\dmrModel;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class UserNurseController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,User $user)
    {
        return $user->where('roll',3)->paginate(1);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,User $user)
    {
        //return $request->all();

        $request->validate([
            'name' => 'required',
            'lastname' => 'required',
            'nationlcode' => 'required',
            'gender' => 'required',
            'password' => ['required', 'string', 'min:8'],
            'phone' => ['required',  'regex:/(09)[0-9]{9}/','digits:11','numeric', 'unique:users'],

        ]);
        // DB::connection('mongodb')->collection('dmr')
        // ->insert(array(
        //     'mobile' => $request->mobile,
        //     'name' => $request->name,
        //     'family' => $request->family,
        //     'nationlcode' => $request->nationlcode,
        //     'gender' => $request->gender,
        //     'password' => $request->password,
        //     'phone' => $request->phone,
        //    ));
        $save = new User();
        $save->phone =$request->phone;
        $msg=trans('website.WellcometoMacisYourpasswordis'.$request->password);
        $msg=trans('website.WellcometoMacisYourpasswordis'.$request->password);
        $save->password = Hash::make($request->password);
        $save->lastname=$request->lastname;
        $save->name=$request->name;
        $save->roll=3;
        $save->confrimmobile=1;
        $save->save();



        dmrModel::create($request->all());
        SendSmsController::sendingsms($request->phone,$msg);

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id,User $user)
    {
       $user=$user->where('id',$id)->where('roll',3)->first();
       $mb=        dmrModel::whereRaw(['phone'=>$user->phone])->first();

    $mb->name=$user->name;
    $mb->lastname=$user->lastname;
    $mb->lastname=$user->lastname;
    $mb->call=$user->lastname;
    $mb->id=$user->id;
    unset($mb->_id);
       return $mb;
    }


    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
