<?php

namespace App\Http\Controllers\View\Medical;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use Illuminate\Support\Facades\Storage;

class Requestresource extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       // return $request->all();
     //   return $request->modelservice['id'];
        $peygiri=date('yd').$request->modelservice['id'].$request->modelservice['sub'].RAND(11111,99999);

        $key='request:free:'.$request->modelservice['id'].':'.$request->modelservice['sub'].':'.$request->mobile.':'.$request->melli.':0:'.$peygiri;
        Redis::hSet($key, 'address', $request->address);
        Redis::hSet($key, 'comments', $request->comments);
        Redis::hSet($key, 'date', $request->date);
        Redis::hSet($key, 'family', $request->family);
        Redis::hSet($key, 'melli', $request->melli);
        Redis::hSet($key, 'mobile', $request->mobile);
        Redis::hSet($key, 'name', $request->name);
        Redis::hSet($key, 'namehamrah', $request->namehamrah);
        Redis::hSet($key, 'nesbat', $request->nesbat);
        Redis::hSet($key, 'service', $request->modelservice['id']);
        Redis::hSet($key, 'subservice', $request->modelservice['sub']);
        Redis::hSet($key, 'phone', $request->phone);
        Redis::hSet($key, 'tellhamrah', $request->tellhamrah);
        Redis::hSet($key, 'peygiri', $peygiri);
        Redis::hSet($key, 'models', $request->models);
        return   response()->json([
            'key'=>$key,
            'peygiri' => $peygiri
        ]);
    }
    public function uploadfile(Request  $request)
    {

        Storage::disk('local')->makeDirectory('document/'.$request->peygiri);
        $extension = $request->file->extension();


        $path = $request->file->storeAs('/document/'.$request->peygiri,$request->peygiri.'.'.$extension);
        Redis::hSet($request->key, 'file', $path);

        return $path;


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
