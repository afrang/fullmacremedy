<?php

namespace App\Object;

use Illuminate\Database\Eloquent\Model;

class object_group extends Model
{
    //
}
