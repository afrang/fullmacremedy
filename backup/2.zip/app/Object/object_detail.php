<?php

namespace App\Object;

use Illuminate\Database\Eloquent\Model;

class object_detail extends Model
{
    function topos(){
        return $this->hasOne(object_group::class,'id','pos');
    }
}
