<?php

use Illuminate\Database\Seeder;

class contactus_methods extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'Offers',
            'formmodel1' => 'input',
            'labelform1' => 'subject',
            'formmodel2' => 'textarea',
            'labelform2' => 'comment',

        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'Complaints',
            'formmodel1' => null,
            'labelform1' => null,
            'formmodel2' => 'textarea',
            'labelform2' => 'Complaints',

        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'Workwithus',
            'formmodel1' => 'input',
            'labelform1' => 'modelwork',
            'formmodel2' => 'textarea',
            'labelform2' => 'morecomment',

        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'Criticismorcomplaints',
            'formmodel1' => 'input',
            'labelform1' => 'subject',
            'formmodel2' => 'textarea',
            'labelform2' => 'morecomment',
        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'Ordertracking',
            'formmodel1' => 'input',
            'labelform1' => 'Ordernumber',
            'formmodel2' => 'textarea',
            'labelform2' => 'morecomment',
        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'aftersalesservice',
            'formmodel1' => 'input',
            'labelform1' => 'Ordernumber',
            'formmodel2' => 'textarea',
            'labelform2' => 'productnameandcomment',
        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'AccountingandFinance',
            'formmodel1' => 'input',
            'labelform1' => 'Ordernumber',
            'formmodel2' => 'textarea',
            'labelform2' => 'morecomment',
        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'Salescooperation',
            'formmodel1' => 'textarea',
            'labelform1' => 'resume',
            'formmodel2' => 'textarea',
            'labelform2' => 'morecomment',
        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'manager',
            'formmodel1' => 'input',
            'labelform1' => 'subject',
            'formmodel2' => 'textarea',
            'labelform2' => 'morecomment',
        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'othersuvject',
            'formmodel1' => 'input',
            'labelform1' => 'subject',
            'formmodel2' => 'textarea',
            'labelform2' => 'morecomment',
        ]);
        DB::table('w_contactus_methodes')->insert([
            'modelname' => 'socialnetwork',
            'formmodel1' => 'input',
            'labelform1' => 'subject',
            'formmodel2' => 'textarea',
            'labelform2' => 'morecomment',
        ]);
    }
}
