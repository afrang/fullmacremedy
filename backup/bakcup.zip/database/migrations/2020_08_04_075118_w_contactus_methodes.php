<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class WContactusMethodes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('w_contactus_methodes', function (Blueprint $table) {
            $table->id();
            $table->string('modelname');
            $table->string('formmodel1')->nullable();
            $table->string('labelform1')->nullable();
            $table->string('formmodel2')->nullable();
            $table->string('labelform2')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('w_contactus_methodes');
    }
}
