<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class MDiscountCodes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('m_discount_codes', function (Blueprint $table) {
            $table->id();
            $table->integer('marketer')->nullable();
            $table->string('code');
            $table->boolean('used')->default(false);
            $table->string('expitetime')->nullable();
            $table->integer('user')->nullable();
            $table->integer('model')->default('1');
            $table->integer('ammount')->default(0);
            $table->string('ammountmode')->default('price');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('m_discount_codes');
    }
}
