<?php

use Illuminate\Database\Seeder;

class object_groups extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('object_groups')->insert([
            'pos' => 'top',
        ]);
        DB::table('object_groups')->insert([
            'pos' => 'down',
        ]);
        DB::table('object_groups')->insert([
            'pos' => 'center',
        ]);
    }
}
