<?php

use Illuminate\Database\Seeder;

class commentsettingseed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('p_comment_settings')->insert([
            'comment' => 'Type Your Condition',

        ]);
    }
}
