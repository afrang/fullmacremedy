<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/
Auth::routes();
/* Sitemap */
Route::resource('/sitemap','sitemapcontroller');

Route::prefix('survey')->namespace('Survey')->group(function (){
        Route::resource('/AuthCheckController','AuthCheckController');
        Route::resource('/ProductSurvayController ','ProductSurvayController');

});
Route::prefix('')->namespace('View')->group(function (){
    Route::resource('/searchproduct','Product\ProductSearchControllerView');
    Route::resource('product','Product\ProductViewController');
    Route::resource('/slider','Tools\GalleryViewController');
    Route::resource('/setting','Tools\SettingpageController');
    Route::resource('/firstpage','Pages\FirstpageController');
    Route::resource('/contactuses','Tools\ContactInfoController');

    /* TAG  SHOW  */

    Route::resource('/tagscontactushow','TagViewController');

    /* Group */
    Route::resource('/pgroup','Product\ProductGroupControllerViewController');
    Route::resource('/psearch','Product\ProductSearchControllerView');
    /* Blog */
    Route::resource('/article','Blog\BlogArticle');
    Route::resource('/blog','Blog\BlogGroup');

    /* Comments */
    Route::resource('settings','Comment\CommentViewSettingController');
    /* Wall */
    Route::resource('/objects','Tools\ObjectControllerView');
    /* Search */
    Route::resource('/search','SearchController');
    /* Contactus */
    Route::resource('/contactus','Contactus\cotactusecontroller');
    /* Special */
    Route::resource('/SpecialProduct','SpecialProductController');
    Route::resource('GetImage','GetImageController');
    /* Medical Service */
    Route::resource('mservice','Medical\Servicescontroller');
    Route::post('requestmedical/uploadfile','Medical\Requestresource@uploadfile');
    Route::resource('requestmedical','Medical\Requestresource');

});
Route::prefix('user')->namespace('User')->middleware('auth:api')->group(function () {
    Route::resource('profile', 'Profile\UserController');


});
Route::middleware('auth:api')->group(function () {
    Route::post('statelist','View\Tools\AddressController@getstate');
    Route::post('countylist','View\Tools\AddressController@countylist');
    Route::post('citylist','View\Tools\AddressController@citylist');
});
Route::prefix('staff')->namespace('staff')->middleware('auth:api')->group(function () {
    Route::resource('triageList', 'triagestaffcontroller');
    Route::resource('proccesslist', 'onProccessListController');
    Route::resource('Listofforms', 'Listofformscontroller');
    Route::resource('fromController', 'FormMedicalController');

});

Route::prefix('nurse')->namespace('Nurse')->middleware('auth:api')->group(function () {
    Route::resource('receptionList', 'Receptionlistcontroller');
    Route::resource('MedicalDocumentController', 'MedicalDocumentController');
    Route::resource('UserController', 'UserNurseController');
    Route::resource('traigeController', 'traigeController');
    Route::resource('listTriage', 'TriageListController');
    Route::resource('doctorController', 'DoctorController');
    Route::resource('listproccess', 'ProccessListController');

});
Route::prefix('Profile')->namespace('Profile')->middleware('auth:api','CheckUser')->group(function () {
    Route::resource('phone', 'PhoneController');
    Route::resource('CompletedRegister', 'CompletedRegisterController');
    Route::resource('SettinginvoiceController', 'SettinginvoiceController');
    Route::resource('AddressController', 'AddressController');
    Route::resource('invoice', 'invoice_invoice_controller');
    Route::resource('fav','productfavscontroller');
    Route::resource('comment','SetCommentController');

    /* Discount */
    Route::resource('discount','Percentcontroller');

});
//Route::prefix('profile')->namespace('Profile')
Route::prefix('user')->namespace('User')->middleware('auth:api','CheckAdmin')->group(function () {

    Route::resource('Joblist', 'Profile\JoblistController');
    Route::resource('Roles', 'Profile\RolesController');
    Route::resource('Users', 'Profile\UsersController');
    Route::resource('Filemanager', 'Filemanager\UploadController');
    Route::resource('fileupload', 'Filemanager\fileupload');
    /* Tags */
    Route::resource('Tag','Tag\TagController');
    /* Blog */
    Route::resource('Bloggroup', 'Blog\GroupController');
    Route::post('Blobggroupupdate/{id}', 'Blog\GroupController@update');
    Route::resource('BlogArticle', 'Blog\ArticleController');
    Route::post('BlogArticleupdate/{id}', 'Blog\ArticleController@update');
    /* Setting */
    Route::resource('SettingController', 'Setting\settingcontroller');
    Route::resource('ContactusController', 'Setting\ContactusController');
    Route::resource('FirstPageSetting', 'Setting\SpecialPageController');
    /* Gallery */
    Route::resource('GalleryGroup', 'Gallery\gallerygroupcontroller');
    Route::resource('GalleryDetail', 'Gallery\gallerydetilcontroller');
    Route::get('GalleryDetailup/{id}', 'Gallery\gallerydetilcontroller@up');
    Route::get('GalleryDetaildown/{id}', 'Gallery\gallerydetilcontroller@down');
    /* Attribute */
    Route::resource('Feature', 'Attr\FeatureController');
    Route::resource('Featureitem', 'Attr\FeatureItemController');
    Route::resource('ModelAttrController', 'Attr\ModelAttrController');
    Route::resource('Attrprodcut', 'Attr\AttrController');
    Route::resource('AttrProductitem', 'Attr\AttrItemController');
    Route::resource('color', 'Attr\ColorController');
    /* Product */
    Route::resource('pgroup', 'Product\ProductGroupController');
    Route::get('pgroupDetailup/{id}', 'Product\ProductGroupController@up');
    Route::get('pgroupDetaildown/{id}', 'Product\ProductGroupController@down');
    /* Product Detail */
    Route::resource('pprice', 'Product\ProductPriceController');

    Route::resource('pdetail', 'Product\ProductDetailController');
    Route::resource('pimage', 'Product\ProductImageController');
    Route::resource('pattr', 'Product\ProductAttrController');
    Route::resource('pfeature', 'Product\ProductFeatureController');
    Route::resource('popt', 'Product\ProdcutOptionController');
    Route::resource('pcolor', 'Product\ProductColorController');
    Route::get('colororderup/{id}', 'Product\ProductColorController@colororderup');
    Route::get('colororderdown/{id}', 'Product\ProductColorController@colororderdown');
    /* Setting Address And Price Devlivery */
    Route::resource('delivery', 'Delivery\PostModeCityController');
    Route::resource('optioninvoice', 'Delivery\PostModeCityController');
    Route::resource('deliveryprice', 'Invoice\delivery_price_controller');
    /* Invoice */
    Route::resource('invoices','Invoice\inovoiceController');
    /* Comment */
    Route::resource('commentsertting','Comment\CommentSettingController');
    Route::resource('commentshow','Comment\CommentController');
    /* Object Detail */
    Route::resource('objectdetail','Object\object_detail_controller');
    Route::resource('objectgroup','Object\object_group_controller');
    /* Discount */
    Route::resource('discount','Discount\Discount_controller');
    /* Static */
    Route::resource('Statictag','Statics\tagStaticController');
    /* SpecialProduct */
    Route::resource('SpecialProducts','Product\Pspecialcontroller');
    /* Request Clinet */
    Route::resource('rclinet','RequestClinet\reequestcontroller');
    /* Medicals Router  */
    Route::resource('medicines','Medical\medicinescontroller');
    Route::resource('service','Medical\service_controller');


});



Route::post('loginuser','Auth\loginPassport@AuthPassport');
Route::resource('syssetting', 'Sys\sys_setting_controller');
