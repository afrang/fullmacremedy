<?php

namespace App\Http\Controllers\Profile;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redis;
use Psy\Util\Json;

class SetCommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $comment                    =array();

        $comment['subject']          =$request->subject;
        $comment['text']             =$request->text;
        $comment['active']           =false;

        Redis::set('comment:'.Auth::id().':'.$request->product,Json::encode($comment));
        Redis::set('subject1:'.Auth::id().':'.$request->product,$request->subject1);
        Redis::set('subject2:'.Auth::id().':'.$request->product,$request->subject2);
        Redis::set('subject3:'.Auth::id().':'.$request->product,$request->subject3);
        Redis::set('subject4:'.Auth::id().':'.$request->product,$request->subject4);
        Redis::set('commentactive:'.Auth::id().':'.$request->product,0);
        return  true;

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

       if( count(Redis::keys('comment:'.Auth::id().':'.$id))==0){
           $comment= collect([
               'count'=>0,

           ]);
       }else{
           $comment= collect([
               'count'=>1,
               'comment'=>Redis::get('comment:'.Auth::id().':'.$id),
               'subject1'=>Redis::get('subject1:'.Auth::id().':'.$id),
               'subject2'=>Redis::get('subject2:'.Auth::id().':'.$id),
               'subject3'=>Redis::get('subject3:'.Auth::id().':'.$id),
               'subject4'=>Redis::get('subject4:'.Auth::id().':'.$id)

           ]);
       }

        return $comment;

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {

    }
}
