<?php

namespace App\Http\Controllers\staff;

use App\Http\Controllers\Controller;
use App\MongoModel\FolowupUserModel;
use App\MongoModel\FormMedical;
use App\MongoModel\FormMedicalBackup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class FormMedicalController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(FormMedical  $FormMedical,Request  $request)
    {
        return $FormMedical->where('id',$request->id)->get();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,FormMedical  $FormMedical)
    {
    $save=[];
    $save['data']=$request->data;
    $save['id']=$request->id;
    $save['mode']=$request->mode;
    $save['ver']='master';
    $save['triage']=$request->triage;
    $save= FormMedical::create($save);
    $save['lastid']=$save['_id'];
    $save->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id,FormMedical  $formMedical)
    {
        return $formMedical->where('_id',$id)->first();

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id,FormMedical  $formMedical,FormMedicalBackup  $formMedicalBackup)
    {
        $data= $formMedical->where('_id',$id)->first();

        $save=[];
        $save['data']=$data['data'];
        $save['mode']=$data['mode'];
        $save['lastid']=$data['lastid'];
        $save['masterid']=$data['masterid'];
        $save['dataenrty']=$data['created_at'];
        $save['id']=$data['id'];

        $newsave=[];
        $newsave['data']=$request->data;
        $newsave['id']=$request->id;
        $newsave['mode']=$request->mode;
        $newsave['ver']='master';
        $newsave['lastid']=$data['lastid'];
         FormMedical::create($newsave);
        $data->delete();
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
