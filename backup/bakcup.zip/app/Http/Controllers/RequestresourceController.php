<?php

namespace App\Http\Controllers;

use App\View\Medical\requestresource;
use Illuminate\Http\Request;

class RequestresourceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\View\Medical\requestresource  $requestresource
     * @return \Illuminate\Http\Response
     */
    public function show(requestresource $requestresource)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\View\Medical\requestresource  $requestresource
     * @return \Illuminate\Http\Response
     */
    public function edit(requestresource $requestresource)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\View\Medical\requestresource  $requestresource
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, requestresource $requestresource)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\View\Medical\requestresource  $requestresource
     * @return \Illuminate\Http\Response
     */
    public function destroy(requestresource $requestresource)
    {
        //
    }
}
