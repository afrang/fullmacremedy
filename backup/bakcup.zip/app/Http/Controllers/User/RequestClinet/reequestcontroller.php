<?php

namespace App\Http\Controllers\User\RequestClinet;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use \Morilog\Jalali;

class reequestcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {

        $myarray=collect();

        $mykey=Redis::keys('Contactus:*'.@$request->group.'*:*'.@$request->peygiri.'*');

        foreach ($mykey as $key){
            $key=str_replace('laravel_database_','',$key);
            $myobject=explode(':',$key);
            if(isset($request->status)){
                if(Redis::hget($key,'status')!=$request->status){
                    continue;
                }
            }

            $comment= collect([
                'email'=>Redis::hget($key,'email'),
                'model'=>Redis::hget($key,'model'),
                'label1'=>Redis::hget($key,'label1'),
                'data1'=>Redis::hget($key,'data1'),
                'label2'=>Redis::hget($key,'label2'),
                'data2'=>Redis::hget($key,'data2'),
                'status'=>Redis::hget($key,'status'),
                'answer'=>Redis::hget($key,'answer'),

                'timestamp'=>Redis::hget($key,'timestamp'),
                'peygiri'=>$myobject[2],
                'jalali'=>Jalali\CalendarUtils::strftime('Y-m-d h:i:s', strtotime(Redis::hget($key,'timestamp')))
            ]);
            $myarray->push($comment);

        }
        return $myarray;

        }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      return Redis::hmset('Contactus:'.$request->model.':'.$id,[
            'answer'=>$request->answer,
            'status'=>$request->status,

        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
