<?php

namespace App\Http\Controllers\User\californiacodes;

use App\Http\Controllers\Controller;
use App\Imports\CaliforniaImport;
use App\MongoModel\CalforniaModel;
use Illuminate\Http\Request;
use League\CommonMark\Inline\Element\Strong;
use Maatwebsite\Excel\Facades\Excel;

class filecaliforniafilecontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
        if($request->code==null) {
            return CalforniaModel::paginate(15);

        }else{
            return CalforniaModel::where('Code','like','%'.$request->code.'%')->paginate(15);

        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $request->validate([
              'file'=>'required|mimes:xls',
          ]);
          $request->file('file')->storeAs('excel','califorania.xls');

      $path=   storage_path('/app/excel').'/califorania.xls';

             $array = Excel::toArray(new CaliforniaImport(), $path);
     //return $array[0];

             foreach ($array[0] as $item=>$value){
                 if($item==0) continue;
                 $id=str_replace('=','',str_replace('"','',$value[1]));
                 CalforniaModel::UpdateOrCreate(['Code'=>$id],[
                     'TerminologyId'=>$value[11],
                     'Group'=>$value[10],
                     'Deleted'=>$value[9],
                     'Version'=>$value[8],
                     'ModificationDate'=>$value[7],
                     'CreationDate'=>$value[6],
                     'AnesthesiaBaseValue'=>$value[5],
                     'RelativeValue'=>$value[4],
                     'Comment'=>$value[3],
                     'Value'=>$value[2],
                     'Code'=>$id,

                 ]);
             }





         }

         /**
          * Display the specified resource.
          *
          * @param  int  $id
          * @return \Illuminate\Http\Response
          */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
