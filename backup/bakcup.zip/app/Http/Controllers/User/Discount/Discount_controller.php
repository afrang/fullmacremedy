<?php

namespace App\Http\Controllers\User\Discount;

use App\Http\Controllers\Controller;
use App\Model\Product\m_discount_code;
use Illuminate\Http\Request;

class Discount_controller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request,m_discount_code $code)
    {
        $mode=0;
        if($request->mode=='unused'){
            $mode=0;
            $codelist=$code->where('used',$mode)->paginate(10);

        }
        if($request->mode=='used'){
            $mode=1;
            $codelist=$code->where('used',$mode)->paginate(10);

        }
        if($request->mode=='expired'){
           // return jdate()
            $codelist=$code->where('used',$mode)->paginate(10);

        }

        return $codelist;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    private function randomnumber($lenght){
        $result='';
        for($i = 0; $i < $lenght; $i++){
            $result .= mt_rand(0,9);
        }
        return  $result;
    }
    public function store(Request $request,m_discount_code $code)
    {
   if($request->model==1){

       for ($x=1; $x <= $request->countcreate;$x++){

           $number=$request->startwith.$this->randomnumber($request->charachter);
           if($code->where('code',$number)->count()==0){
               $save                                = new $code;
               $save->code                          =$number;
               $save->used                          =false;
               $save->expitetime                    =$request->expitetime;
               $save->model                         =1;
               $save->ammount                       =$request->ammount;
               $save->ammountmode                   =$request->ammountmode;
               $save->save();
           }else{
               $x--;
           }


       }
       return  $code;


   }else{
       if($code->where('code',$request->code)->count()==0) {

           $save = new $code;
           $save->code = $request->code;
           $save->used = false;
           $save->expitetime = $request->expitetime;
           $save->model = 2;
           $save->ammount = $request->ammount;
           $save->ammountmode = $request->ammountmode;
           $save->save();
       }else{
           $save= $code->where('code',$request->code)->first();
           $save->code = $request->code;
           $save->used = false;
           $save->expitetime = $request->expitetime;
           $save->model = 2;
           $save->ammount = $request->ammount;
           $save->ammountmode = $request->ammountmode;
           $save->save();
       }
   }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id,m_discount_code $code)
    {
     $code->where('id',$id)->delete();
    }
}
