<?php

namespace App\Http\Controllers\User\Tools;

use App\Http\Controllers\Controller;
use App\Imports\CaliforniaImport;
use App\MongoModel\CalforniaModel;
use App\MongoModel\DrugeModel;
use App\MongoModel\ToolsModels;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class listToolsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
        if($request->code==null){
            return ToolsModels::paginate(15);

        }else{
            return ToolsModels::where('name','like','%'.$request->code.'%')->paginate(15);

        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'file'=>'required|mimes:xls',
        ]);
        $request->file('file')->storeAs('excel','tools.xls');

        $path=   storage_path('/app/excel').'/tools.xls';

        $array = Excel::toArray(new CaliforniaImport(), $path);
        //return $array[0];
        foreach ($array[0] as $item=>$value){
            if($item==0) continue;
            // return $value;
            ToolsModels::UpdateOrCreate(['name'=>$value[1]],[

                'PricePerUnit'=>$value[4],
                'Companyname'=>$value[3],
                'Code'=>$value[2],
                'persianname'=>$value[1],
                'name'=>$value[0],

            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
