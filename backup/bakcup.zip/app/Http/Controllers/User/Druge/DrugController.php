<?php

namespace App\Http\Controllers\User\Druge;

use App\Http\Controllers\Controller;
use App\Imports\CaliforniaImport;
use App\MongoModel\CalforniaModel;
use App\MongoModel\DrugeModel;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class DrugController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request  $request)
    {
        if($request->code==null){
            return DrugeModel::paginate(15);

        }else{
            return DrugeModel::where('name','like','%'.$request->code.'%')->paginate(15);

        }

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'file'=>'required|mimes:xls',
        ]);
        $request->file('file')->storeAs('excel','drug.xls');

        $path=   storage_path('/app/excel').'/drug.xls';

        $array = Excel::toArray(new CaliforniaImport(), $path);
        //return $array[0];
        foreach ($array[0] as $item=>$value){
            if($item==0) continue;
           // return $value;
            DrugeModel::UpdateOrCreate(['name'=>$value[1]],[
                'Date'=>$value[10],
                'Remarks'=>$value[9],
                'Accesslevel'=>$value[8],
                'Approvedclinicalindications'=>$value[7],
                'Ingredient'=>$value[6],
                'ATCCode'=>$value[5],
                'RouteofAdmin'=>$value[4],
                'Strengh'=>$value[3],
                'DosageForm'=>$value[2],
                'Salt'=>$value[1],
                'name'=>$value[0],

            ]);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
