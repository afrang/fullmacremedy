<?php

namespace App\Http\Controllers\User\Setting;

use App\Http\Controllers\Controller;
use App\Model\Pages\page_setting;
use Illuminate\Http\Request;

class SpecialPageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,page_setting $page_setting)
    {

        foreach ($request->all() as $key=>$index){

            $data=[];
         if($key=='mode') continue;
         if($key=='lang') continue;
             if($index['mode']=='slider'){
                 $data=$this->getSliderdata($index['data']);

                 $page_setting->updateOrCreate(
                     ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                     ['image'=>$data,'model'=>'slider']
                 );
             };
            if($index['mode']=='text'){
                $data=$index['data'];
                $page_setting->updateOrCreate(
                    ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                    ['image'=>$data,'model'=>'text']
                );
            };
            if($index['mode']=='img'){
                $data=$index['data'];
                $page_setting->updateOrCreate(
                    ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                    ['image'=>$data,'model'=>'img']
                );
            };
            if($index['mode']=='longtext'){
                $data=$index['data'];
                $page_setting->updateOrCreate(
                    ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                    ['text'=>$data,'model'=>'longtext']
                );
            };
            if($index['mode']=='timepicker'){
                $page_setting->updateOrCreate(
                    ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                    ['text'=>$index['start'],'image'=>$index['end'],'model'=>'timepicker']
                );
            };
            if($index['mode']=='product'){
                $data=$this->getSliderdata($index['data']);


                $page_setting->updateOrCreate(
                    ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                    ['image'=>$data,'model'=>'product']
                );
            };
            if($index['mode']=='tag'){
                $data=$index['data'];
                $page_setting->updateOrCreate(
                    ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                    ['image'=>$data,'model'=>'tag']
                );
            };
            if($index['mode']=='tagarticle'){
                $data=$index['data'];
                
                $page_setting->updateOrCreate(
                    ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                    ['image'=>$data,'model'=>'tagarticle']
                );
            };
            if($index['mode']=='article'){
                $data=$this->getSliderdata($index['data']);

                $page_setting->updateOrCreate(
                    ['lang'=>$request->lang,'name'=>$key,'method'=>$request->mode],
                    ['image'=>$data,'model'=>'article']
                );
            };
        }
    }
    private function getSliderdata($data){

        return @$data['id'];
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id,Request $request,page_setting $page_setting)
    {


        $data=$page_setting->where('method',$id)->where('lang',$request->lang)->get();
        return $data;

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
