<?php

namespace App\Http\Controllers;

use App\Http\Resources\sitemapproductresource;
use App\Model\Blog\b_article;
use App\Model\Blog\b_group;
use App\Model\Product\p_group;
use App\Model\Product\p_prodcut;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class sitemapcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $procut=p_prodcut::select('url')->get();
        foreach ($procut as $key){
            $key['mode']='product';
        }
        $pgroup=p_group::select('url')->get();
        foreach ($pgroup as $key){
            $key['mode']='category';
        }
        $article=b_article::select('url')->get();
        foreach ($article as $key){
            $key['mode']='article';
        }
        $group=b_group::select('url')->get();
        foreach ($group as $key){
            $key['mode']='blog';
        }
        $array = array_merge($pgroup->toArray(), $procut->toArray(),$article->toArray(),$group->toArray());
        return $array;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
