<?php

namespace App\Http\Controllers\Nurse;

use App\Http\Controllers\Controller;
use App\Http\Resources\Doctor\DoctoruserResource;
use App\MongoModel\Doctor\docotorUser;
use App\MongoModel\Log\NurseLog;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class DoctorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request,User $user)
    {
        $list=$user->where('roll',2)->paginate(2);
     return DoctoruserResource::collection($list);

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,User $user)
    {

       $request->validate([
           'phone' => ['required',  'regex:/(09)[0-9]{9}/','digits:11','numeric', 'unique:users'],
           'name' => ['required'],
           'Evidence' => ['required'],
           'email' => ['required','unique:users'],
           'family' => ['required'],
           'password' => ['required', 'string', 'min:8'],


       ]);
        $user = new User();
        $user->phone= $request->phone;
        $user->name= $request->name;
        $user->phone= $request->phone;
        $user->email= $request->email;
        $user->lastname= $request->lastname;
        $user->roll= 2;
        $user->password= Hash::make($request->password);
        $user->save();
        $request->parent=$user->id;
        $my=[];
        $my['parent']=$user->id;
        $my['address']=$request->address;
        $my['address2']=$request->address2;
        $my['Specialty']=$request->Specialty;
        $my['Evidence']=$request->Evidence;
        $my['university']=$request->university;
        $my['family']=$request->family;
        $my['inputer']=Auth::id();

            docotorUser::create($my);

            $log=[];
            $log['event']='Add Doctor';
            $log['user']=Auth::id();
            $log['messege']=Auth::user()->name .' Add a doctor User with name'.$request->name . ' '. $request->family;
            NurseLog::create($log);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
