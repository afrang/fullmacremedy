<?php

namespace App\Http\Controllers\Nurse;

use App\Http\Controllers\Controller;
use App\Model\Medical\m_service;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;

class Receptionlistcontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $myarray=collect();

        $mykey=Redis::keys('request:*');
        foreach ($mykey as $key){
              //  return $key;
            $key=str_replace('laravel_database_','',$key);

            $comment= collect([
                'address'=>Redis::hget($key,'address'),
                'comments'=>Redis::hget($key,'comments'),
                'family'=>Redis::hget($key,'family'),
                'melli'=>Redis::hget($key,'melli'),
                'mobile'=>Redis::hget($key,'mobile'),
                'name'=>Redis::hget($key,'name'),
                'namehamrah'=>Redis::hget($key,'namehamrah'),
                'nesbat'=>Redis::hget($key,'nesbat'),
                'service'=>m_service::where('id',Redis::hget($key,'service'))->first()->name,
                'subservice'=>m_service::where('id',Redis::hget($key,'subservice'))->first()->name,
                'phone'=>Redis::hget($key,'phone'),
                'tellhamrah'=>Redis::hget($key,'tellhamrah'),
                'peygiri'=>Redis::hget($key,'peygiri'),
                'models'=>Redis::hget($key,'models'),
                'file'=>Redis::hget($key,'file'),
                'key'=>$key,
            ]);
            $myarray->push($comment);

        }
        return $myarray;

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
