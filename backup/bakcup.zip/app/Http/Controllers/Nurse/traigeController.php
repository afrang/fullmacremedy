<?php

namespace App\Http\Controllers\Nurse;

use App\Http\Controllers\Controller;
use App\Http\Resources\UsersmdrResource;
use App\MongoModel\Accounter\TransactionModel;
use App\MongoModel\dmrModel;
use App\MongoModel\FolowupUserModel;
use App\MongoModel\Log\NurseLog;
use App\MongoModel\TriageModel;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class traigeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(dmrModel $dmr)
    {
       $user=$dmr->where('triage', 'exists', false)->get();
        return UsersmdrResource::collection($user);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

      $t=TriageModel::create($request->all());
        $log=[];
        $log['event']='Add Triage';
        $log['user']=Auth::id();
        $log['messege']=Auth::user()->name .' Add Triage '.$request->name . ' '. $request->family;
        NurseLog::create($log);
        $trans=[];
        $trans['parent']=$request->user;
        $trans['log']=Auth::user()->name .'  '.$request->name . ' '. $request->family . '.Add price to Charged:'.$request->price;
        $trans['mode']='TriageModel';
        $trans['idmode']=$t['_id'];
        $trans['recived']=$request->price;
        $trans['inputer']=Auth::id();
        $trans['peygiri']=null;
        TransactionModel::create($trans);
        $save=[];
        $save['document']=$t['_id'];
        $save['user']=$request->doctor['id'];
        $save['event']='leaddoctor';
        $save['permision']='all';
        FolowupUserModel::create($save);
        $save=[];
        $save['document']=$t['_id'];
        $save['user']=$request->trapist['id'];
        $save['event']='trapist';
        $save['permision']='all';
        FolowupUserModel::create($save);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id,User $user,dmrModel $dmr)
    {
       $m=$user->where('id',$id)->first();
        $user=$dmr->where('phone', $m->phone)->first();
        return UsersmdrResource::make($user);

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
