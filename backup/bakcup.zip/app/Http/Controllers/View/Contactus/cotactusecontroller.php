<?php

namespace App\Http\Controllers\View\Contactus;

use App\Http\Controllers\Controller;
use App\Model\contactus\w_contactus_methode;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redis;
use phpseclib\Crypt\Random;
use \Morilog\Jalali;

class cotactusecontroller extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(w_contactus_methode $methode)
    {
        return   $methode->get();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $create=date('mh').rand(11111,99999);
      Redis::hmset('Contactus:'.$request->model.':'.$create,[
        'timestamp'=>Carbon::now()->toDateTimeString(),
        'email'=>$request->email,
        'model'=>$request->model,
        'label1'=>$request->lable1,
        'data1'=>$request->data1,
        'label2'=>$request->lable2,
        'data2'=>$request->data2,
        'peygiri'=>$create,
        'answer'=>'',
        'status'=>0,

    ]);
            return $create;
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $key='Contactus:socialnetwork:'.$id;
        $myarray=collect();
        $comment= collect([
            'model'=>Redis::hget($key,'model'),
            'status'=>Redis::hget($key,'status'),
            'answer'=>Redis::hget($key,'answer'),

            'timestamp'=>Redis::hget($key,'timestamp'),
            'peygiri'=>$id,
            'jalali'=>Jalali\CalendarUtils::strftime('Y-m-d h:i:s', strtotime(Redis::hget($key,'timestamp')))
        ]);
        $myarray->push($comment);

       return  $myarray;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
