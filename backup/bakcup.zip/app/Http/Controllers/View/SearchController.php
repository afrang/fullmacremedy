<?php

namespace App\Http\Controllers\View;

use App\Http\Controllers\Controller;
use App\Http\Controllers\User\Blog\ArticleController;
use App\Http\Resources\Blog\BlogArticlethumpresource;
use App\Http\Resources\ProdcutThumpnailResource;
use App\Http\Resources\SearchResource;
use App\Model\Blog\b_article;
use App\Model\Product\p_prodcut;
use Illuminate\Http\Request;

class SearchController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $listarticle=BlogArticlethumpresource::collection(b_article::where('name','LIKE','%'.$request->id.'%')->where('group','!=',1)->paginate(3));
       // return $listarticle;
        $product=ProdcutThumpnailResource::collection(p_prodcut::where('name','LIKE','%'.$request->id.'%')->paginate(15));
        $item['article']=$listarticle;
        $item['product']=$product;
        return SearchResource::make($request->id,$request->page);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
