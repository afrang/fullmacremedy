<?php

namespace App\Http\Controllers\Applicant;

use App\Http\Controllers\Controller;
use App\MongoModel\UserDocuments;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Intervention\Image\ImageManager;
use Laravel\Ui\UiServiceProvider;
use const http\Client\Curl\AUTH_DIGEST;

class UserDocumentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(UserDocuments $documents)
    {
        return $documents->where('parent',Auth::id())->get();

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request,User  $user)
    {
        $request->validate([
            'file'=>'required|mimes:jpg,png,jpeg,bmp',
        ]);
        Storage::disk('local')->makeDirectory('/UserDocument/'.Auth::id());
        $fileName = time().'.'.$request->file->extension();
        $manager = new ImageManager();
        $manager->make($request->file)->save(storage_path().'/app/UserDocument/'.Auth::id().'/'.$fileName);
        $save=new UserDocuments();
        $save->name=$request->name;
        $save->date=$request->date;
        $save->parent=Auth::id();
        $save->file=$fileName;

        $save->type=$request->file->extension();
        $save->save();

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
