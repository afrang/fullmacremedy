<?php

namespace App\Http\Controllers\Applicant;

use App\Http\Controllers\Controller;
use App\MongoModel\dmrModel;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class Profile extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  $request->validate([
        'name' => 'required',
        'lastname' => 'required',
        'city' => 'required',
        'state' => 'required',
        'address' => 'required',
        'nationlcode' => 'required',
        'gender' => 'required',

    ]);
        // DB::connection('mongodb')->collection('dmr')
        // ->insert(array(
        //     'mobile' => $request->mobile,
        //     'name' => $request->name,
        //     'family' => $request->family,
        //     'nationlcode' => $request->nationlcode,
        //     'gender' => $request->gender,
        //     'password' => $request->password,
        //     'phone' => $request->phone,
        //    ));

        $save =Auth::user();
        $save->lastname=$request->lastname;
        $save->name=$request->name;
        $save->roll=3;
        $save->confrimmobile=1;
        $save->save();

        dmrModel::create($request->all());


    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id,user $user)
    {
        $request->validate([
            'name' => 'required',
            'lastname' => 'required',
            'city' => 'required',
            'state' => 'required',
            'address' => 'required',
            'nationlcode' => 'required',
            'gender' => 'required',

        ]);
        $user=$user->where('id',Auth::id())->where('roll',3)->first();

        $save =Auth::user();
        $save->lastname=$request->lastname;
        $save->name=$request->name;
        $save->roll=3;
        $save->confrimmobile=1;
        $save->save();
        dmrModel::whereRaw(['phone'=>$user->phone])->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
