<?php

namespace App\Http\Resources\Doctor;

use App\MongoModel\Doctor\docotorUser;
use App\User;
use Illuminate\Http\Resources\Json\JsonResource;

class DoctoruserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $user=docotorUser::where('parent',$this->id)->first();

         return [
             'id'=>$this->id,
             'name'=>$this->name,
             'lastname'=>$this->lastname,
             'phone'=>$this->phone,
             'email'=>$this->email,
             'fullname'=>$this->name.' '.$user->family,
             'address'=>@$user->address,
             'address2'=>@$user->address2,
             'Specialty'=>@$user->Specialty,
             'Evidence'=>@$user->Evidence,
             'university'=>@$user->Evidence,
             'family'=>@$user->family,
             'inputer'=>@User::where('id',@$user->inputer)->select(['name','lastname'])->first()
         ];
    }
}
