<?php

namespace App\Http\Resources;

use App\Http\Resources\Blog\BlogArticleResource;
use App\Http\Resources\Blog\BlogArticlethumpresource;
use App\Model\Blog\b_article;
use App\Model\Product\p_prodcut;
use App\Model\Tags\tag;
use Illuminate\Http\Resources\Json\JsonResource;

class Viewspecialresource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */

    public function toArray($request)
    {
        $data=null;
        if($this->model=='article'){
                if($this->image!=null){
                    $data=b_article::where('id',$this->image)->with('toArticle','totags')->first();
                }
        };
        if($this->model=='text'){
            if($this->image!=null){
                $data=$this->image;
            }
        };
        if($this->model=='tag'){

            if($this->image!=null){
                $name=@json_decode($this->image, true)['name'];;
                if($name!=null){
                    $data=tag::where('name',$name)->with('toProduct')->first();
                    $data=$data->toProduct() ->with('toPrice','ToImage','toColor')->orderBy('id','DESC')->get();
                    $data=ProdcutThumpnailResource::collection(
                        $data
                    );
                }

            }
        };
        if($this->model=='tagarticle'){
            $data=$this->image;
          if($this->image!=null){
                $name=json_decode($this->image, true)['name'];;
                $data=tag::where('name',$name)->with('toArticle')->first();
                $data=BlogArticlethumpresource::collection($data->toArticle()->with('toArticle')->get());
               /* $data=$data->toProduct() ->with('toPrice','ToImage','toColor')->orderBy('id','DESC')->get();
              $data=ProdcutThumpnailResource::collection(
                  $data
                );*/
            }
        };

        if($this->model=='product'){
            if($this->image!=null){
                $data=ProdcutThumpnailResource::make(p_prodcut::where('id',$this->image)->with('toPrice','ToImage','toColor')->first());
            }
        }
        if($this->model=='img'){
            if($this->image!=null){
                $data=$this->image;
            }
        };
        return [
            'name'=>$this->name,
            'model'=>$this->model,
            'data'=>$data,

            ];
    }
}
