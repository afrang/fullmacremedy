<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceDetailShowResouce extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        $price=null;
        if($this->mode==1){
            $price=$this->price;
        }
        if($this->mode==2){
            $price=(($this->width/100)*($this->height/100))*$this->price;
  /*          let w=this.witdh/100;
        let h=this.height/100;

        return (w*h)*this.product.price;*/
        }
        //return parent::toArray($request);
        return [
            'Qty'=>$this->Qty,
            'attrvalue'=>$this->attrvalue,
            'attrvalue'=>$this->attrvalue,
            'colorcode'=>$this->colorcode,
            'discount'=>$this->discount,
            'modelname'=>$this->modelname,
            'width'=>$this->width,
            'height'=>$this->height,
            'src'=>$this->src,
            'mode'=>$this->mode,
            'optionvalue'=>$this->optionvalue,
            'parentproduct'=>$this->parentproduct,
            'price'=>$price,
            'productname'=>$this->productname,
            'status'=>$this->status,
            'total'=>$this->Qty*$price,
            'totaldiscount'=>($this->Qty*$price)-($this->Qty*$this->discount),
        ];
    }
}
