<?php

namespace App\Model\Sys;

use Illuminate\Database\Eloquent\Model;

class contactu extends Model
{
    //
}
