<?php

namespace App\Model\Sys;

use Illuminate\Database\Eloquent\Model;

class sys_setting extends Model
{
    //
}
