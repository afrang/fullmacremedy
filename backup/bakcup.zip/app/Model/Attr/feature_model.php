<?php

namespace App\Model\Attr;

use Illuminate\Database\Eloquent\Model;

class feature_model extends Model
{
    //
}
