<?php

namespace App\Model\Attr;

use Illuminate\Database\Eloquent\Model;

class p_color extends Model
{
    //
}
