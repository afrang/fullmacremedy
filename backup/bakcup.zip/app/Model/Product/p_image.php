<?php

namespace App\Model\Product;

use Illuminate\Database\Eloquent\Model;

class p_image extends Model
{
   protected  $fillable=['master'];
}
