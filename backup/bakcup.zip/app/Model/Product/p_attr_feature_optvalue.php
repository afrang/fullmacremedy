<?php

namespace App\Model\Product;

use Illuminate\Database\Eloquent\Model;

class p_attr_feature_optvalue extends Model
{
    //
}
