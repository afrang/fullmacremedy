<?php

namespace App\Model\Medical;

use Illuminate\Database\Eloquent\Model;

class m_service extends Model
{
    function toSub(){
        return $this->hasMany(m_service::class,'sub','id');
    }
}
