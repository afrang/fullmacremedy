<?php

namespace App\Model\contactus;

use Illuminate\Database\Eloquent\Model;

class w_contactus_methode extends Model
{
    //
}
