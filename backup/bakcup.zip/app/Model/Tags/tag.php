<?php

namespace App\Model\Tags;

use App\Model\Product\p_prodcut;
use Illuminate\Database\Eloquent\Model;

class tag extends Model
{
    protected $fillable=['name'];
    function toArticle(){
        return $this->belongsToMany('App\Model\Blog\b_article','attr_article_to_tag','article','tag');
    }
    function toBlog(){
        return $this->belongsToMany('App\Model\Blog\b_group','attr_blog_g_tag','blog','tag');
    }
    function toProduct(){
            return $this->belongsToMany('App\Model\Product\p_prodcut','p_attr_pdetail_tags','product','tag');
    }
}
