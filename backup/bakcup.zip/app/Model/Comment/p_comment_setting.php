<?php

namespace App\Model\Comment;

use Illuminate\Database\Eloquent\Model;

class p_comment_setting extends Model
{
    //
}
