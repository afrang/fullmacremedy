<?php

namespace App\Model\Address;

use Illuminate\Database\Eloquent\Model;

class address_ostan extends Model
{
    //
}
