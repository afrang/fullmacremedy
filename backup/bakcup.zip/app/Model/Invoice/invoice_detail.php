<?php

namespace App\Model\Invoice;

use Illuminate\Database\Eloquent\Model;

class invoice_detail extends Model
{
    //
}
