<?php

namespace App\MongoModel;

use Jenssegers\Mongodb\Eloquent\Model;

class FormMedical extends Model
{
    protected $collection = 'formmedical';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'data','id','mode','status','writter','lastid','ver','triage'
        ];
}
