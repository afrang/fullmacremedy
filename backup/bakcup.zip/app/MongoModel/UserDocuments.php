<?php

namespace App\MongoModel;

use Jenssegers\Mongodb\Eloquent\Model;

class UserDocuments extends Model
{
    protected $collection = 'ud';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'name',
        'date',
        'file',
        'filetype',
        'parent',
    ];
}
