<?php

namespace App\MongoModel\Log;

use Jenssegers\Mongodb\Eloquent\Model;

class NurseLog extends Model
{
    protected $collection = 'log_nurse';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'event',
        'messege',
        'user',
    ];


}
