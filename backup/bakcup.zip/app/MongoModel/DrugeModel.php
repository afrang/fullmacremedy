<?php

namespace App\MongoModel;

use Jenssegers\Mongodb\Eloquent\Model;

class DrugeModel extends Model
{
    protected $collection = 'drug';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'name',
        'Salt',
        'DosageForm',
        'Strengh',
        'RouteofAdmin',
        'ATCCode',
        'Ingredient',
        'Approvedclinicalindications',
        'Accesslevel',
        'Remarks',
        'Date',
    ];
}
