<?php

namespace App\MongoModel;

use Jenssegers\Mongodb\Eloquent\Model;

class FormMedicalBackup extends Model
{
    protected $collection = 'formmedicalbackup';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'data','id','mode','status','writter','lastid','ver','dataenrty'
        ];
}
