<?php

namespace App\MongoModel;

use App\User;
use Jenssegers\Mongodb\Eloquent\Model;

class FolowupUserModel extends Model
{
    protected $collection = 'folowupuser';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'document',
        'user',
        'event',
        'permision'
        ];
    public function toTraige(){
        return $this->hasOne(TriageModel::class,'_id','document');
    }
    public function toUser(){
        return $this->hasOne(User::class,'id','user');
    }


}
