<?php

namespace App\MongoModel\Accounter;

use Jenssegers\Mongodb\Eloquent\Model;

class SettingAccounting extends Model
{
    protected $collection = 'SettingAccounting';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'TeleMadisonSpecialistnurse',
        'TeleMadisonDoctor',
        'TeleMadisonSpecialty',

        'data',
        'Presencenurse',
        'PresenceSpecialistnurse',
        'PresenceDoctor',
        'PresenceSpecialty',


        'ReferenceDoctor',
        'ReferenceSpecialty',

        'Schiffnurse',
        'Schifflistnurse',

    ];
}
