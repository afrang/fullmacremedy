<?php

namespace App\MongoModel\Doctor;

use Jenssegers\Mongodb\Eloquent\Model;

class docotorUser extends Model
{
    protected $collection = 'doctor';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'parent',
        'address',
        'address2',
        'Specialty',
        'Evidence',
        'inputer',
        'family',
        'university',
    ];


}
