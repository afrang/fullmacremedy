<?php

namespace App\MongoModel;

use Jenssegers\Mongodb\Eloquent\Model;

class ToolsModels extends Model
{
    protected $collection = 'tools';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'name',
        'persianname',
        'Code',
        'Companyname',
        'PricePerUnit',

    ];
}
