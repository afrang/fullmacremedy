<?php

namespace App\MongoModel;

use Jenssegers\Mongodb\Eloquent\Model;

class CalforniaModel extends Model
{
    protected $collection = 'cal';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'TerminologyId',
        'Group',
        'Deleted',
        'Version',
        'ModificationDate',
        'CreationDate',
        'AnesthesiaBaseValue',
        'RelativeValue',
        'Comment',
        'Value',
        'Code',
        'Attribute',
];
}
