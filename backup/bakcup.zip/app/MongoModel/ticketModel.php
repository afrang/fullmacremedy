<?php

namespace App\MongoModel;
use Jenssegers\Mongodb\Eloquent\Model;


class ticketModel extends Model
{
    protected $collection = 'ticket';
    protected $connection ='mongodb';
    protected $primary = 'id';
    protected $fillable = [
        'subject',
        'parent',
        'status',
        'title',
        'description',
        'file',
        'user',
        'sender',
        'type'
    ];
    function ToAnswer(){
        return $this->hasMany(ticketModel::class,'parent','_id');
    }
}
